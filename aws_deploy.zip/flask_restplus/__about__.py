# -*- coding: utf-8 -*-
__version__ = '0.11.0'
__description__ = 'Fully featured framework for fast, easy and documented API development with Flask'
