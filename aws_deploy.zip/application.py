# add this for elastic beans stack deployment 
# required python3.7 and pip3.7

from app import app as application  # bdpts

if __name__ == "__main__":
    application.run()
